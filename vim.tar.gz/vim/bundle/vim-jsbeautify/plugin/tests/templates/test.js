(["foo","bar"]).each(function(i) {
return i;});
